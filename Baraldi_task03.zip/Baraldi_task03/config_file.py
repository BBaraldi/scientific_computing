from generate_vectors import prefix

N = 10
a = 3

# Input/output filenames
x_file = f"{prefix}vector_N{N}_x.dat"
y_file = f"{prefix}vector_N{N}_y.dat"
output_file = f"{prefix}vector_N{N}_d.dat"
